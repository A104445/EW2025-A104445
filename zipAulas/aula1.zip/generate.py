import json
import os
import shutil

def open_json(filename):
    # Open and read the JSON file
    with open(filename, 'r', encoding='utf-8') as file:
        data = json.load(file)
        
        # Use when you have the text and not the file ref
        # fileText = file.read()
        # data = json.loads(fileText)

    return data


def mk_dir(relative_path):
    if not os.path.exists(relative_path):   # create folder
        os.mkdir(relative_path)
    else:                                   # delete folder content
        shutil.rmtree(relative_path)
        os.mkdir(relative_path)
        
        
def new_file(filename, content):
    f = open(filename, 'w', encoding='utf-8')
    f.write(content)
    f.close()

# lista_nif = []
# lista_matricula = []
# json_obj = open_json('dataset_reparacoes.json')
# for reparacao in json_obj['reparacoes']:
#     nif = reparacao['nif']
#     matricula = reparacao['viatura']['matricula']
    
#     # Verifica NIF
#     if(nif in lista_nif):
#         print(f'O nif {nif} já existe')
#     else:    
#         lista_nif.append(nif)
    
#     # Verifica Matricula
#     if(matricula in lista_matricula):
#         print(f'A matricula {matricula} já existe')
#     else:    
#         lista_matricula.append(matricula)


# Lista de Reparações
html = '''
<html>
    <head>
        <title>Reparações</title>
    </head>
    <body>
        <h1>Reparações</h1>
        <ul>
'''
json_obj = open_json('dataset_reparacoes.json')
for reparacao in json_obj['reparacoes']:
    data = reparacao['data']
    nif = reparacao['nif']
    nome = reparacao['nome']
    marca = reparacao['viatura']['marca']
    modelo = reparacao['viatura']['modelo']
    nr_intervencoes = reparacao['nr_intervencoes']
    
    html += f'<li>{data} || {nif} || {nome} || {marca} || {modelo} || {nr_intervencoes}</li>'

html += '''
        </ul>
    </body>
</html>
'''

new_file('lista_geral.html', html)



# Lista de Intervencoes
html = '''
<html>
    <head>
        <title>Intervenções</title>
    </head>
    <body>
        <h1>Intervenções</h1>
        <ul>
'''
map_intervencoes = {}
json_obj = open_json('dataset_reparacoes.json')
for reparacao in json_obj['reparacoes']:
    for intervencao in reparacao['intervencoes']:
        map_intervencoes[intervencao['codigo']] = intervencao
    
for codigo in sorted(map_intervencoes.keys()):
    nome = map_intervencoes[codigo]['nome']
    descricao = map_intervencoes[codigo]['descricao']
    html += f'<li>{codigo} || {nome} || {descricao}</li>'

html += '''
        </ul>
    </body>
</html>
'''

new_file('lista_intervencoes.html', html)



# Lista de Carros
html = '''
<html>
    <head>
        <title>Carros</title>
    </head>
    <body>
        <h1>Carros</h1>
        <ul>
'''
map_carros = {}
json_obj = open_json('dataset_reparacoes.json')
for reparacao in json_obj['reparacoes']:
    viatura = reparacao['viatura']
    marca = viatura['marca']
    if marca in map_carros:
        modelo = viatura['modelo']
        if modelo in map_carros[marca]:
            map_carros[marca][modelo] += 1
        else:
            map_carros[marca][modelo] = 1
    else:
        map_carros[marca] = {}
        map_carros[marca][viatura['modelo']] = 1

for marca in sorted(map_carros.keys()):
    count_marca = 0
    html_modelos = '<ul>'
    modelos = map_carros[marca]
    for modelo in sorted(modelos.keys()):
        count = map_carros[marca][modelo]
        count_marca += count
        html_modelos += f'<li>{modelo} - #{count}</li>'
    html_modelos += '</ul>'
    html += f'<li>{marca} - #{count_marca}</li>'
    html += html_modelos

html += '''
        </ul>
    </body>
</html>
'''

new_file('lista_carros.html', html)