const http = require('http')
const meta = require('./aux')

http.createServer((req, res) => {
    
    switch(req.method){
        case 'GET':
            if(req.url === '/data'){
                res.writeHead(200, {'Content-Type' : 'text/html;charset=utf-8'})
                res.write("<p>Hello World à turma</p>")
                res.write(meta.myDate())
            }
            else if(req.url === '/nome'){
                res.writeHead(200, {'Content-Type' : 'text/html;charset=utf-8'})
                res.write("<p>Hello World à turma</p>")
                res.write(meta.myName())
            }
            else if(req.url === '/turma'){
                res.writeHead(200, {'Content-Type' : 'text/html;charset=utf-8'})
                res.write("<p>Hello World à turma</p>")
                res.write(meta.turma)
            }else{
                res.writeHead(404, {'Content-Type' : 'text/html;charset=utf-8'})
            }
            break;
        default:
            res.writeHead(405, {'Content-Type' : 'text/html;charset=utf-8'})
            break;
    }

    res.end()
}).listen(4321)

console.log("Server listen in port 4321...")