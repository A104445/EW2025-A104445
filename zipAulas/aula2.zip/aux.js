exports.myDate = () => {
    return new Date().toISOString().substring(0,16)
}

exports.myName = function() {
    return 'Tiago Barata'
}

exports.turma = 'EngWeb2025::TP2'