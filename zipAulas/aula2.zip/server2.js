const http = require('http')
const meta = require('./aux')

http.createServer((req, res) => {
    console.log(req.url)
    console.log(req.method)
    res.writeHead(200, {'Content-Type' : 'text/html;charset=utf-8'})
    res.write("<p>Hello World à turma</p>")
    switch(req.url){
        case '/data':
            res.write(meta.myDate())
            break;
        case '/nome':
            res.write(meta.myName())
            break;
        case '/turma':
            res.write(meta.turma)
            break
        default:
            break
    }

    res.end()
}).listen(4321)

console.log("Server listen in port 4321...")