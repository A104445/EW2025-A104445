
exports.genCidades = function(cidades, date){
    var pagHTML = `
    <!DOCTYPE html>
    <html>
        <head>
            <meta charset="UTF-8"/>
            <title>Cidades</title>
            <link rel="stylesheet" type="text/css" href="/w3.css"/>
        </head>
        <body>
            <div class="w3-card-4">
                <header class="w3-container w3-purple">
                    <h1>Cidades</h1>
                </header>

                <div class="w3-container">
                    <ul class="w3-ul">`
                    
                    cidades.forEach(element => {
                        pagHTML += `<li>
                            <a href='/cidades/${element.id}'>${element.nome}</a>
                        </li>`
                    });

                    pagHTML += `</ul>
                </div>
                
                <footer class="w3-container w3-purple">
                    <h5>Generated in EngWeb2025 ${date}</h5>
                </footer>
            </div>
        </body>
    </html>
    `
    return pagHTML
}


exports.genCidade = function(cidade, ligacoes, mapCidades, date){
    var pagHTML = `
    <!DOCTYPE html>
    <html>
        <head>
            <meta charset="UTF-8"/>
            <title>Cidades</title>
            <link rel="stylesheet" type="text/css" href="/w3.css"/>
        </head>
        <body>
            <div class="w3-card-4">
                <header class="w3-container w3-purple">
                    <h1>${cidade.nome}</h1>
                    <h3>${cidade.distrito}</h3>
                </header>

                <div class="w3-container">
                    <p><b>População:</b> ${cidade['população']}</p>
                    <p><b>Descrição:</b> ${cidade['descrição']}</p>
                </div>

                <div class="w3-container">
                    <table class="w3-table-all">
                            <tr>
                                <th>Destino</th>
                                <th>Distância</th>
                            </tr>`
                    ligacoes.forEach(ligacao => {
                        pagHTML += `<tr>
                            <td><a href='/cidades/${ligacao.destino}'>${mapCidades.get(ligacao.destino)}</a></td>
                            <td>${ligacao['distância']}</td>
                        </tr>
                        `
                    })
                pagHTML += `
                    </table>
                </div>
                <h6><a href='/cidades' class='w3-button'>Voltar</a></h6>
                <footer class="w3-container w3-purple">
                    <h5>Generated in EngWeb2025 ${date}</h5>
                </footer>
            </div>
        </body>
    </html>
    `
    return pagHTML
}