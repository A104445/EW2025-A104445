def calcular_ciclo_recorrente(d):
    restos = {}
    resto = 1
    posicao = 0

    while resto != 0:
        if resto in restos:
            return posicao - restos[resto]
        restos[resto] = posicao
        resto = (resto * 10) % d
        posicao += 1

    return 0

def encontrar_maior_ciclo(limite):
    max_ciclo = 0
    resultado = 0

    for d in range(2, limite):
        tamanho_ciclo = calcular_ciclo_recorrente(d)
        if tamanho_ciclo > max_ciclo:
            max_ciclo = tamanho_ciclo
            resultado = d

    return resultado, max_ciclo

# Exemplo: encontrar o denominador até 1000
limite = 1000
resultado, max_ciclo = encontrar_maior_ciclo(limite)
print(f"O denominador {resultado} tem o ciclo recorrente mais longo de {max_ciclo} dígitos.")
