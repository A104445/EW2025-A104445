var File = require('../model/file')

module.exports.findFiles = () => {
    return File
        .find()
        .exec()
}

module.exports.save = (file, name, path) => {
    var fileDb = new File({
        name : name,
        originalName: file.originalname,
        date : new Date().toISOString().substring(0,19),
        mimetype : file.mimetype,
        size : file.size,
        path : path
    })

    fileDb.save()
}