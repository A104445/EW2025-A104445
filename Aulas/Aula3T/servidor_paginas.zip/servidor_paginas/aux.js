export function myDateTime () {
    var d = new Date().toISOString().substring(0, 16)
    return d
}
    
export function myName () {
    return "José Carlos Ramalho"
}

export const turma = "EngWeb2025::T1"
    
    